#include "stm32f10x.h"                  // Device header                 
#include "CarCtrl.h" 
#include "Exti.h"
#include "TCRT5000.h"

int main(void)
{   
	Car_Init();
	EXTIx_Init();
	TCRT5000_Init();
	while(1)
	{
		if(TCRT5000_Get1() == 1)
		{
			Car_Forward();
		}
		else
		{
			Car_Rightward();
		}
	}
}
