#include "stm32f10x.h"                  // Device header

//外部循迹模块
void TCRT5000_Init(void)
{
//	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE); //打开时钟设置
//	GPIO_InitTypeDef GPIO_InitsStructure;  //定义结构体
//	GPIO_InitsStructure.GPIO_Mode = GPIO_Mode_IPU;  //选择上拉输出
//	GPIO_InitsStructure.GPIO_Pin = GPIO_Pin_14;  //选择端口
//	GPIO_InitsStructure.GPIO_Speed = GPIO_Speed_50MHz;  //选择速度
//	GPIO_Init(GPIOB, &GPIO_InitsStructure);  //地址传递加&	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB | RCC_APB2Periph_AFIO, ENABLE);
	GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE);
	GPIO_InitTypeDef GPIO_InitsStructure;
	GPIO_InitsStructure.GPIO_Mode = GPIO_Mode_IPD;
	GPIO_InitsStructure.GPIO_Pin = GPIO_Pin_15;
	GPIO_InitsStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitsStructure);
	
    GPIO_InitsStructure.GPIO_Mode = GPIO_Mode_IPD;
	GPIO_InitsStructure.GPIO_Pin = GPIO_Pin_3 | GPIO_Pin_4;
	GPIO_InitsStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitsStructure);
}

uint8_t TCRT5000_Get1(void)  //返回输入端口值
{
	return GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_15);
}

uint8_t TCRT5000_Get2(void)  //返回输入端口值
{
	return GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_3);
}

uint8_t TCRT5000_Get3(void)  //返回输入端口值
{
	return GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_4);
}
