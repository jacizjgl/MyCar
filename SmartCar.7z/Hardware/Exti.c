#include "stm32f10x.h"                  // Device header
#include "Key.h" 
//#include "CarCtrl.h" 

//外部中断服务程序
uint8_t KeyNum;

void EXTIx_Init(void)
{
	EXTI_InitTypeDef EXTI_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	
	Key_Init();
//	Car_Init();

	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);//使能复用功能时钟
	
	//PA12，中断线及中断初始化配置，下降沿触发
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource12);
	EXTI_InitStructure.EXTI_Line = EXTI_Line12;
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	EXTI_Init(&EXTI_InitStructure);
	
	//PA7，中断线及中断初始化配置，上升沿触发
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource7);
	EXTI_InitStructure.EXTI_Line = EXTI_Line7;
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	EXTI_Init(&EXTI_InitStructure);	
	
	NVIC_InitStructure.NVIC_IRQChannel = EXTI9_5_IRQn;//使能按键所在的通道
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;
	NVIC_Init(&NVIC_InitStructure);
	
	NVIC_InitStructure.NVIC_IRQChannel = EXTI15_10_IRQn;//使能按键所在的通道
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	NVIC_Init(&NVIC_InitStructure);
}

void EXTI9_5_IRQHandler(void)
{
//	if(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_5) == 1)
//	{
//		Car_Forward();
//	}	
//	KeyNum = Key_GetNum();
//	if(KeyNum == 1)//PA7
//	{
//		Car_Rightward();
//	}		
	EXTI_ClearITPendingBit(EXTI_Line7);
}

void EXTI15_10_IRQHandler(void)
{
	KeyNum = Key_GetNum();
	if(KeyNum == 2)//PA12
	{
		//Car_Leftward();
	}
	EXTI_ClearITPendingBit(EXTI_Line12);
}
