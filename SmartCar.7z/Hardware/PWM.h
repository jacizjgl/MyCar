#ifndef __PWM_H__
#define __PWM_H__

void TIM1_PWM_Init(uint16_t ARR, uint16_t PSC);

#endif
