#ifndef __EXTI_H__
#define __EXTI_H__

void EXTIx_Init(void);
void EXTI9_5_IRQHandler(void);
void EXTI15_10_IRQHandler(void);

#endif
