#ifndef __PWM_SERVO_H__
#define __PWM_SERVO_H__

void PWM_Servo_Init(void);
void PWM_Servo_SetCompare2(uint16_t Compare);

#endif
