#include "stm32f10x.h"                  // Device header
#include "PWM.h"
#include "TB6612.h"

void Motor_Init(void)
{	
	TB6612_GPIO_Init();
	TIM1_PWM_Init(36-1, 100-1);//72M进行36分频，计100个数
}

void Motor1_SetSpeed(int8_t Speed1)//电机1速度-100到100
{
	if(Speed1>=0)//电机正转
	{
		GPIO_SetBits(GPIOB,AN1);
		GPIO_ResetBits(GPIOB,AN2);
		TIM_SetCompare1(TIM1, Speed1);		
	}
	else //反转
	{
		GPIO_SetBits(GPIOB,AN2);		
		GPIO_ResetBits(GPIOB,AN1);
		TIM_SetCompare1(TIM1, -Speed1);				
	}
}

void Motor2_SetSpeed(int8_t Speed2)//电机2速度-100到100
{
	if(Speed2>=0)//电机正转
	{
		GPIO_SetBits(GPIOB,BN1);
		GPIO_ResetBits(GPIOB,BN2);
		TIM_SetCompare4(TIM1, Speed2);
	}
	else //反转
	{
		GPIO_SetBits(GPIOB,BN2);		
		GPIO_ResetBits(GPIOB,BN1);
		TIM_SetCompare4(TIM1, -Speed2);		
	}
}
