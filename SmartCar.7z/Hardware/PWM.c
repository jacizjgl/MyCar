#include "stm32f10x.h"                  // Device header

void TIM1_PWM_Init(uint16_t ARR, uint16_t PSC)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);//开启TIM1的时钟
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_AFIO, ENABLE);//使能AFIO复用模块时钟
		
	GPIO_InitTypeDef GPIO_InitStructure;
	TIM_OCInitTypeDef TIM_OCInitStructure;	
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;	
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;  //复用推挽输出
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_11;//定时器1通道1和通道4
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure); 
	
	TIM_InternalClockConfig(TIM1);//使用STM32内部时钟源

	//配置时基单元
	TIM_TimeBaseInitStructure.TIM_ClockDivision = 0;//决定时钟1分频参数
	TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;//向上计数模式
	TIM_TimeBaseInitStructure.TIM_Period = ARR;//自动重装器计ARR个数，所以就是 (ARR)
	TIM_TimeBaseInitStructure.TIM_Prescaler = PSC;//预分频器对72M分PSC得到，减1是因为误差  （PSC）(人耳听不到)
	TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;//高级计数器使用，这里不需要给0	
	TIM_TimeBaseInit(TIM1, &TIM_TimeBaseInitStructure);	
	

	//配置定时器通道
//	TIM_OCStructInit(&TIM_OCInitStructure);//对结构体赋一个初始值，想更改单独改即可
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;//输出比较模式
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;//输出极性选择
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;//输出状态使能
	TIM_OCInitStructure.TIM_Pulse = 0;   //CCR的值,频率1KHz,分辨率1%,改变占空比CCR	
	TIM_OC1Init(TIM1, &TIM_OCInitStructure);//初始化通道1
	TIM_OC1PreloadConfig(TIM1, TIM_OCPreload_Enable);//使能TIM1在CCR1上的预载寄存器

	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;//输出比较模式
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;//输出极性选择
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;//输出状态使能
	TIM_OCInitStructure.TIM_Pulse = 0;   //CCR的值,频率1KHz,分辨率1%,改变占空比CCR	
	TIM_OC4Init(TIM1, &TIM_OCInitStructure);//初始化通道4
	TIM_OC4PreloadConfig(TIM1, TIM_OCPreload_Enable);	
	
	TIM_CtrlPWMOutputs(TIM1, ENABLE);//高级定时器MOE主输出模式，必须有
	
	TIM_Cmd(TIM1, ENABLE);	
}
