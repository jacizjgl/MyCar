#ifndef __MOTOR_H__
#define __MOTOR_H__

void Motor_Init(void);
void Motor1_SetSpeed(int8_t Speed1);//定时器1通道1，PA8
void Motor2_SetSpeed(int8_t Speed2);//定时器1通道4，PA11

#endif
