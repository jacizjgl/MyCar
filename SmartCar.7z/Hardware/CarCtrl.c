#include "stm32f10x.h"                  // Device header
#include "Motor.h" 
#include "Servo.h"

void Car_Init(void)
{
	Motor_Init();
	Servo_Init();
}

void Car_Forward(void)//小车向前
{
	Servo_SetAngle(90);
	Motor1_SetSpeed(10);
	Motor2_SetSpeed(10);
}

void Car_Backward(void)//小车向后
{
	Servo_SetAngle(90);
	Motor1_SetSpeed(-10);
	Motor2_SetSpeed(-10);
}

void Car_Rightward(void)//小车向右
{
	Servo_SetAngle(135);
	Motor1_SetSpeed(10);
	Motor2_SetSpeed(-10);
}

void Car_Leftward(void)//小车向左
{
	Servo_SetAngle(45);
	Motor1_SetSpeed(-10);
	Motor2_SetSpeed(10);
}


