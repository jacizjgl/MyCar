#ifndef __SERVO_H__
#define __SERVO_H__

void Servo_Init(void);
void Servo_SetAngle(float Angle);

#endif
