#ifndef __TB6612_H__
#define __TB6612_H__

#define AN1	GPIO_Pin_13
#define	AN2 GPIO_Pin_12
#define	BN1 GPIO_Pin_1
#define	BN2	GPIO_Pin_0

void TB6612_GPIO_Init(void);

#endif
