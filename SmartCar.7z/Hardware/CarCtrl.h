#ifndef __CARTRL_H__
#define __CARTRL_H__

void Car_Init(void);
void Car_Forward(void);
void Car_Backward(void);
void Car_Rightward(void);
void Car_Leftward(void);

#endif
