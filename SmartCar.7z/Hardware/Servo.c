#include "stm32f10x.h"                  // Device header
#include "PWM_Servo.h"

void Servo_Init(void)
{
	PWM_Servo_Init();
}

void Servo_SetAngle(float Angle)//对应0到180度，线性变化所以符合方程
{
	PWM_Servo_SetCompare2(Angle / 180 * 2000 + 500);
}
