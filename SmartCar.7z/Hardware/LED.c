#include "stm32f10x.h"                  // Device header

void LED_Init(void)  
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE); //打开时钟设置
	GPIO_InitTypeDef GPIO_InitsStructure;  //定义结构体
	GPIO_InitsStructure.GPIO_Mode = GPIO_Mode_Out_PP;  //选择推挽输出
	GPIO_InitsStructure.GPIO_Pin = GPIO_Pin_1 | GPIO_Pin_2;  //选择端口，或上即可
	GPIO_InitsStructure.GPIO_Speed = GPIO_Speed_50MHz;  //选择速度
	GPIO_Init(GPIOA, &GPIO_InitsStructure);  //地址传递加&
	
	GPIO_SetBits(GPIOA, GPIO_Pin_1 | GPIO_Pin_2);  //初始化口为高电平
}

void LED1_ON(void)
{
	GPIO_ResetBits(GPIOA, GPIO_Pin_1);
}

void LED1_OFF(void)
{
	GPIO_SetBits(GPIOA, GPIO_Pin_1);
}

void LED2_ON(void)
{
	GPIO_ResetBits(GPIOA, GPIO_Pin_2);
}

void LED2_OFF(void)
{
	GPIO_SetBits(GPIOA, GPIO_Pin_2);
}

void LED1_Turn(void)  //状态取反，对于输出寄存器
{
	if(GPIO_ReadOutputDataBit(GPIOA, GPIO_Pin_1) == 0)
	{
		GPIO_SetBits(GPIOA, GPIO_Pin_1);
	}
	else
	{
		GPIO_ResetBits(GPIOA, GPIO_Pin_1);
	}
}

void LED2_Turn(void)  //状态取反，对于输出寄存器
{
	if(GPIO_ReadOutputDataBit(GPIOA, GPIO_Pin_2) == 0)
	{
		GPIO_SetBits(GPIOA, GPIO_Pin_2);
	}
	else
	{
		GPIO_ResetBits(GPIOA, GPIO_Pin_2);
	}
}
