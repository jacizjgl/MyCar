#ifndef __TCRT5000_H__
#define __TCRT5000_H__

void TCRT5000_Init(void);
uint8_t TCRT5000_Get1(void);
uint8_t TCRT5000_Get2(void);
uint8_t TCRT5000_Get3(void);

#endif
