#ifndef _LK_H
#define _LK_H
#include "sys.h"

void read_sensor(void);
void hongwai_Init(void);
#endif
