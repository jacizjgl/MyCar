#ifndef __LED1_H
#define __LED1_H
#include "sys.h"
void LED1_Init(void);


#endif



