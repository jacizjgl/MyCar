#ifndef __KEY_H
#define __KEY_H	 
#include "sys.h"
 
					    
#endif


