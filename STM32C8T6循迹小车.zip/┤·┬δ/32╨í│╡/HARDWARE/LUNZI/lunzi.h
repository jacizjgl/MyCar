#ifndef __LUNZI_H
#define __LUNZI_H
void lunzi_Init(void);

void forward(void);

void stop(void);




#endif




